# Sistema Hotelero

Proyecto básico de gestión hotelera en PHP. Permite administrar reservas, habitaciones y usuarios.

Desarrollado como parte del curso de Programación Web e Ingeniería de Software.
