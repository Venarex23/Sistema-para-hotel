<?php
echo "<h1>Bienvenido al Sistema Hotelero</h1>";
?>
