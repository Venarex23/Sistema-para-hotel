<?php
// Página de inicio de sesión
echo "<h2>Login del sistema hotelero</h2>";
?>
